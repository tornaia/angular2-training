import {Component} from 'angular2/core';

@Component({
    selector: 'luxury',
    template: `<h1>Luxury Component</h1>`
})
export class LuxuryComponent {}