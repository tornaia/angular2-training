import {Component} from 'angular2/core';

@Component({
    selector: 'product-description',
    template: '<p></p>This is a great product!'
})
export class ProductDescriptionComponent {}