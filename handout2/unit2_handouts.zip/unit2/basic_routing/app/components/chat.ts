import {Component} from 'angular2/core';

@Component({
    selector: 'chat',
    template: `<h1>Chat Component</h1>
               `
})
export class ChatComponent {}