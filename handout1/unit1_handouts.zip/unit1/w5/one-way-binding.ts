import {bootstrap} from 'angular2/platform/browser';
import {Component} from 'angular2/core';

@Component({
  selector: 'one-way-binding',
  template: `
      <h1>{{ name }}</h1>
          <button (click)="changeName()">Change Name</button>
  `
})
class AppComponent {
  name: string = "Mary Smith";

  changeName(){
    this.name = "Bill Smart";
  }
}

bootstrap(AppComponent);
