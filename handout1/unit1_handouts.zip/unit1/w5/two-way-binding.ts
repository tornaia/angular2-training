import {bootstrap} from 'angular2/platform/browser';
import {Component} from 'angular2/core';

@Component({
    selector: 'two-way-binding',
    template: `<input type='text' placeholder= "Enter shipping address" [(ngModel)] = "shippingAddress">
                <button (click)="shippingAddress='123 Main Street'">Set Default Address</button>
               <p>The shipping address is {{shippingAddress}}</p>
               `
})
class AppComponent {

    shippingAddress: string;
}

bootstrap(AppComponent);