import {Component} from 'angular2/core';

@Component({
  selector: 'auction-carousel',
  templateUrl: 'app/components/carousel/carousel.html'
})
export default class CarouselComponent {}
