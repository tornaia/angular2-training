import {Component} from 'angular2/core';

@Component({
  selector: 'auction-search',
  templateUrl: 'app/components/search/search.html'
})
export default class SearchComponent {}
