import {Component} from 'angular2/core';

@Component({
  selector: 'auction-footer',
  templateUrl: 'app/components/footer/footer.html'
})
export default class FooterComponent {}
