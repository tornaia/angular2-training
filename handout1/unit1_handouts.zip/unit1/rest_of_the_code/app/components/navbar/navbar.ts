import {Component} from 'angular2/core';

@Component({
  selector: 'auction-navbar',
  templateUrl: 'app/components/navbar/navbar.html'
})
export default class NavbarComponent {}
