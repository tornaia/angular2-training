function* doSomething(){

    console.log("Started processing");

    yield;

    console.log("Resumed processing");
}

let iterator = doSomething();

iterator.next();