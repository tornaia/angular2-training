/*
 This version of main.ts illustrates the use of useFactory and useValue
 */

import {bootstrap} from 'angular2/platform/browser';
import {Component, provide} from 'angular2/core';

class Product {
  constructor(public title: string) {}
}

abstract class ProductService {
  abstract getProduct(): Product;
}

class RealProductService implements ProductService{
  getProduct(): Product {
    return new Product('iPhone 7');
  }
}

class MockProductService implements ProductService {
  getProduct(): Product {
    return new Product('Samsung 7');
  }
}

// The first component gets a default RealProductService injected
@Component({
  selector: 'product1',
  template: '{{product.title}}'})
class Product1Component {
  product: Product;

  constructor(productService: ProductService) {
    this.product = productService.getProduct();
  }
}


// The second components uses factory to decide which service to inject
@Component({
  selector: 'product2',

  providers: [provide(ProductService,{useFactory:
            (isDev) =>{
                      if (isDev){
                        return new MockProductService();
                      } else{
                        return new RealProductService();
                      }
            }, deps:["IS_DEV_ENVIRONMENT"]})],
  template: '{{product.title}}'
 })
class Product2Component {
  product: Product;

  constructor(productService: ProductService) {
    this.product = productService.getProduct();
  }
}

// Root component hosts two product components
@Component({
  selector: 'disample-root',
  directives: [
    Product1Component,
    Product2Component
  ],
  template: `
    <h2>A root component hosts two products<br> provided by different services</h2>
    <product1></product1>
    <br>
    <product2></product2>
  `
})
class RootComponent {}


bootstrap(RootComponent, [provide(ProductService,{useClass:RealProductService}),
                          provide("IS_DEV_ENVIRONMENT",{useValue:true})]);
