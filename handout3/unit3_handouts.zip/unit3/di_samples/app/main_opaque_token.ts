import {bootstrap} from 'angular2/platform/browser';
import {Component, OpaqueToken, provide, Inject} from 'angular2/core';

export const BACKEND_URL  = new OpaqueToken('BackendUrl');
export const BACKEND_URL2  = new OpaqueToken('BackendUrl');

@Component({
  selector: 'disample-root',
  template: 'URL: {{url}}'
})
class RootComponent {
  constructor(@Inject(BACKEND_URL) public url: string) {}
}

bootstrap(RootComponent, [
  provide(BACKEND_URL, {useValue: 'myDevServer.com'})
  , provide(BACKEND_URL2, {useExisting: BACKEND_URL})
]);
